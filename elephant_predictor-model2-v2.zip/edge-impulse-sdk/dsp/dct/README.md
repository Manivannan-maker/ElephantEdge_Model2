# Fast discrete cosine transform algorithms (C)

DCT type 2 and type 3 algorithms based on https://www.nayuki.io/page/fast-discrete-cosine-transform-algorithms. These are modified to use KissFFT or hardware accelerated RFFT support with CMSIS-DSP.
